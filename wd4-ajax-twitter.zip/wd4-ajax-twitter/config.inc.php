<?php

$twitteruser = "twitterusername";
$consumerkey = "44VsDURBQgcNuOCvbSnsEHipB";
$consumersecret = "WiiB67P2TrIN5p3WuIvJCzNpB23uWCgsFteeL1x1r8FprqglVW";
$accesstoken = "22012405-yBqVDm0kuEQmewFE7SeIEPKoQZh9qhsQhK7g5M7PF";
$accesstokensecret = "ki5XR8jaCMYaQ67XInG6yUFnkU0K55LCWZUnSWeqAzPh9";